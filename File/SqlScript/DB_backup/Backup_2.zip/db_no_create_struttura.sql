-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: biglietteriaonline
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `biglietti`
--

DROP TABLE IF EXISTS `biglietti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biglietti` (
  `COD_OPERAZIONE` int NOT NULL AUTO_INCREMENT,
  `COD_CLIENTE` int NOT NULL,
  `COD_REPLICA` char(4) NOT NULL,
  `DATA_ORA` datetime NOT NULL,
  `TIPO_PAGAMENTO` char(20) NOT NULL,
  `QUANTITA` int DEFAULT NULL,
  PRIMARY KEY (`COD_OPERAZIONE`),
  KEY `COD_CLIENTE` (`COD_CLIENTE`),
  KEY `COD_REPLICA` (`COD_REPLICA`),
  CONSTRAINT `biglietti_ibfk_1` FOREIGN KEY (`COD_CLIENTE`) REFERENCES `clienti` (`COD_CLIENTE`),
  CONSTRAINT `biglietti_ibfk_2` FOREIGN KEY (`COD_REPLICA`) REFERENCES `repliche` (`COD_REPLICA`),
  CONSTRAINT `biglietti_chk_1` CHECK ((`TIPO_PAGAMENTO` in (_utf8mb4'Carta di Credito',_utf8mb4'Bonifico')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clienti`
--

DROP TABLE IF EXISTS `clienti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clienti` (
  `COD_CLIENTE` int NOT NULL AUTO_INCREMENT,
  `COGNOME` varchar(20) NOT NULL,
  `NOME` varchar(20) NOT NULL,
  `TELEFONO` varchar(14) NOT NULL,
  `EMAIL` varchar(30) NOT NULL,
  PRIMARY KEY (`COD_CLIENTE`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `repliche`
--

DROP TABLE IF EXISTS `repliche`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repliche` (
  `COD_REPLICA` char(4) NOT NULL,
  `COD_SPETTACOLO` char(4) DEFAULT NULL,
  `DATA_REPLICA` date DEFAULT NULL,
  PRIMARY KEY (`COD_REPLICA`),
  KEY `COD_SPETTACOLO` (`COD_SPETTACOLO`),
  CONSTRAINT `repliche_ibfk_1` FOREIGN KEY (`COD_SPETTACOLO`) REFERENCES `spettacoli` (`COD_SPETTACOLO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `spettacoli`
--

DROP TABLE IF EXISTS `spettacoli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spettacoli` (
  `COD_SPETTACOLO` char(4) NOT NULL,
  `TITOLO` varchar(80) DEFAULT NULL,
  `AUTORE` varchar(25) DEFAULT NULL,
  `REGISTA` varchar(25) DEFAULT NULL,
  `PREZZO` decimal(4,2) DEFAULT NULL,
  `COD_TEATRO` int DEFAULT NULL,
  PRIMARY KEY (`COD_SPETTACOLO`),
  KEY `COD_TEATRO` (`COD_TEATRO`),
  CONSTRAINT `spettacoli_ibfk_1` FOREIGN KEY (`COD_TEATRO`) REFERENCES `teatri` (`COD_TEATRO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `teatri`
--

DROP TABLE IF EXISTS `teatri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teatri` (
  `COD_TEATRO` int NOT NULL AUTO_INCREMENT,
  `NOME` varchar(30) DEFAULT NULL,
  `INDIRIZZO` varchar(30) DEFAULT NULL,
  `CITTA` varchar(25) DEFAULT NULL,
  `PROVINCIA` char(2) DEFAULT NULL,
  `TELEFONO` char(14) DEFAULT NULL,
  `POSTI` int DEFAULT NULL,
  PRIMARY KEY (`COD_TEATRO`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-18 11:59:44
